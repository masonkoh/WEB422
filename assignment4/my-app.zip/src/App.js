class App extends Component {

  render() {
    let url = "";    
    // url will be added later
    return ( 

    ); 
  }  
}

export default App;