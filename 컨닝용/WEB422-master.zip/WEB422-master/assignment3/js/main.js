/*********************************************************************************
* WEB422 – Assignment 3
* I declare that this assignment is my own work in accordance with Seneca Academic Policy.
* No part of this assignment has been copied manually or electronically from any other source
* (including web sites) or distributed to other students.
*
* Name: Fernando Henrique Zavalloni Proto    Student ID: 128133154    Date: 28/Sep/2017
*
*
********************************************************************************/

var viewModel = {
    teams: [],
    employees: [],
    projects: []
};

function initializeTeams() {
    return new Promise(function (resolve, reject) {
        $.ajax({
            url: 'https://radiant-mesa-48727.herokuapp.com/teams-raw',
            type: "GET",
            contentType: "application/json"
        })
            .done(function (data) {
                viewModel.teams = ko.mapping.fromJS(data);
                //console.log(viewModel);
                resolve(data);
            })
            .fail(function (err) {
                reject("Error loading the team data.");
            });
    })
}


function initializeEmployees() {
    return new Promise(function (resolve, reject) {
        $.ajax({
            url: 'https://radiant-mesa-48727.herokuapp.com/employees',
            type: "GET",
            contentType: "application/json"
        })
            .done(function (data) {
                viewModel.employees = ko.mapping.fromJS(data);
                resolve(data);
            })
            .fail(function (err) {
                reject("Error loading the employee data.");
            });
    })
}



function initializeProjects() {
    return new Promise(function (resolve, reject) {
        $.ajax({
            url: 'https://radiant-mesa-48727.herokuapp.com/projects',
            type: "GET",
            contentType: "application/json"
        })
            .done(function (data) {
                viewModel.projects = ko.mapping.fromJS(data);
                resolve(data);
            })
            .fail(function (err) {
                reject("Error loading the project data.");
            });
    })
}


function showGenericModal(title, message) {
    $('.modal-title').html(title);
    $('.modal-body').html(message);
    $('#genericModal').modal('show');
}

function saveTeam() {
    let currentTeam = this;
    $.ajax({
        url: "https://radiant-mesa-48727.herokuapp.com/team/" + currentTeam._id(),
        type: "PUT",
        data: JSON.stringify({
            Projects: currentTeam.Projects(),
            Employees: currentTeam.Employees(),
            TeamLead: currentTeam.TeamLead()
        }),
        contentType: "application/json"
    })
        .done(function (data) {
            showGenericModal('Success', currentTeam.TeamName() + ' Updated Successfully')
        })
        .fail(function (err) {
            showGenericModal('Error', 'Error updating the team information.');
        });
}

$(function () { // Handler for .ready() called.
    console.log("JQuery Working");
    
    initializeTeams()
        .then(initializeEmployees)
        .then(initializeProjects)
        .then(function () {
            ko.applyBindings(viewModel);
            $('.multiple').multipleSelect({ filter: true });
            $('.single').multipleSelect({ single: true, filter: true });
        }).catch(function (err) {
            showGenericModal('Error', 'Unable to get the data');
        })
});
